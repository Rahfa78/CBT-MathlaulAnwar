plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "id.sch.smkmathlaulanwar.cbt"
    compileSdk = 34

    defaultConfig {
        applicationId = "id.sch.smkmathlaulanwar.cbt"
        minSdk = 23
        targetSdk = 33
        versionCode = 1
        versionName = "3.1"
    }

    signingConfigs {
        create("mathlaulanwarReleaseKey") {
            storeFile = file("mathlaulanwar_release.jks")
            storePassword = "mathlaulanwar2026"
            keyAlias = "mathlaulanwarkey"
            keyPassword = "mathlaulanwar2026"
            enableV1Signing = true
            enableV2Signing = true
        }
    }

    buildTypes {
        getByName("debug") {
            signingConfig = signingConfigs.getByName("mathlaulanwarReleaseKey")
        }
        getByName("release") {
            isMinifyEnabled = false
            isShrinkResources = false
            signingConfig = signingConfigs.getByName("mathlaulanwarReleaseKey")
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
}
